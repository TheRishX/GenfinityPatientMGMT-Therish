import express from 'express';
import path from 'path';
import fs from 'fs/promises';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { createServer as createNetServer } from 'net';
import { createServer as createViteServer } from 'vite';
import nodemailer from 'nodemailer';
import dotenv from 'dotenv';
import mysql, { Pool } from 'mysql2/promise';
import { createHmac, timingSafeEqual } from 'crypto';
import { DatabaseSchema, Patient, PatientFile, Appointment, Authorization, Claim, ClinicSettings, FabricationItem, AlertItem, SmtpConfig, EmailTemplate, EmailLog, SmsLog, SmsTemplate } from './src/types.js';

// Hostinger deployments can provide a private runtime file alongside standard
// environment variables. Local development continues to use `.env`.
dotenv.config({ path: process.env.RUNTIME_ENV_PATH || 'hostinger.runtime' });
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PRIVATE_STORAGE_PATH = process.env.PRIVATE_STORAGE_PATH || path.resolve(__dirname, '..', 'private-clinic-storage');
const LOCAL_DATABASE_PATH = path.join(__dirname, 'src', 'db.json');
const isLocalDevelopment = process.env.NODE_ENV === 'development';

// Hostinger's environment editor can normalize these identifiers to uppercase,
// while MySQL account names on the server are lowercase and case-sensitive.
// Normalize identifiers only; passwords must remain byte-for-byte unchanged.
const MYSQL_HOST = process.env.MYSQL_HOST?.trim();
const MYSQL_DATABASE = process.env.MYSQL_DATABASE?.trim().toLowerCase();
const MYSQL_USER = process.env.MYSQL_USER?.trim().toLowerCase();
const MYSQL_PASSWORD = process.env.MYSQL_PASSWORD;

const mysqlConfigured = Boolean(
  MYSQL_HOST &&
  MYSQL_DATABASE &&
  MYSQL_USER &&
  MYSQL_PASSWORD
);
// Never let copied production credentials make a localhost server depend on
// Hostinger. Remote MySQL is an explicit local-development opt-in, while
// deployed environments continue to use MySQL by default.
const useRemoteMysql = !isLocalDevelopment || process.env.MYSQL_USE_REMOTE === 'true';
const useLocalJsonDatabase = isLocalDevelopment && !useRemoteMysql;

const BREVO_API_KEY = process.env.BREVO_API_KEY?.trim();
const BREVO_SMTP_HOST = process.env.BREVO_SMTP_HOST?.trim() || 'smtp-relay.brevo.com';
const BREVO_SMTP_PORT = Number(process.env.BREVO_SMTP_PORT || 587);
const BREVO_SMTP_USER = process.env.BREVO_SMTP_USER?.trim();
const BREVO_SMTP_PASSWORD = process.env.BREVO_SMTP_PASSWORD?.trim();
const BREVO_FROM_EMAIL = process.env.BREVO_FROM_EMAIL?.trim();
const BREVO_SENDER_NAME = process.env.BREVO_SENDER_NAME?.trim() || 'Genfinity O&P';
const BREVO_REPLY_TO = process.env.BREVO_REPLY_TO?.trim();
const RINGCENTRAL_SERVER_URL = (process.env.RC_SERVER_URL?.trim() || 'https://platform.ringcentral.com').replace(/\/$/, '');
const RC_APP_CLIENT_ID = process.env.RC_APP_CLIENT_ID?.trim();
const RC_APP_CLIENT_SECRET = process.env.RC_APP_CLIENT_SECRET?.trim();
const RC_USER_JWT = process.env.RC_USER_JWT?.trim();
const RC_FROM_PHONE_NUMBER = process.env.RC_FROM_PHONE_NUMBER?.trim();
let ringCentralToken: { accessToken: string; expiresAt: number } | null = null;

let mysqlPool: Pool | null = null;

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const probe = createNetServer();
    probe.once('error', () => resolve(false));
    probe.listen(port, '0.0.0.0', () => {
      probe.close(() => resolve(true));
    });
  });
}

async function findAvailablePort(preferredPort: number): Promise<number> {
  for (let offset = 0; offset < 20; offset += 1) {
    const candidate = preferredPort + offset;
    if (await isPortAvailable(candidate)) return candidate;
  }
  return 0;
}

function mysqlErrorMessage(error: any): string {
  const code = error?.code ? ` (${error.code})` : '';
  return `${error?.message || 'Unknown MySQL error'}${code}`;
}

function mysqlErrorHint(error: any): string | null {
  switch (error?.code) {
    case 'ER_ACCESS_DENIED_ERROR':
      return 'Verify MYSQL_USER and MYSQL_PASSWORD in Hostinger, then confirm this database user is allowed to connect from the deployed server host.';
    case 'ER_BAD_DB_ERROR':
      return 'Verify MYSQL_DATABASE matches the database name shown in Hostinger hPanel.';
    case 'ENOTFOUND':
    case 'ECONNREFUSED':
    case 'ETIMEDOUT':
      return 'Verify MYSQL_HOST, MYSQL_PORT, and Hostinger remote MySQL access settings.';
    default:
      return null;
  }
}

function getMysqlPool(): Pool | null {
  if (!mysqlConfigured) return null;
  if (!mysqlPool) {
    mysqlPool = mysql.createPool({
      host: MYSQL_HOST,
      port: Number(process.env.MYSQL_PORT || 3306),
      database: MYSQL_DATABASE,
      user: MYSQL_USER,
      password: MYSQL_PASSWORD,
      connectionLimit: Number(process.env.MYSQL_CONNECTION_LIMIT || 8),
      waitForConnections: true,
      enableKeepAlive: true,
      keepAliveInitialDelay: 0,
      charset: 'utf8mb4'
    });
  }
  return mysqlPool;
}

async function ensureMysqlSchema(pool: Pool): Promise<void> {
  await pool.execute(`
    CREATE TABLE IF NOT EXISTS app_state (
      state_key VARCHAR(64) NOT NULL PRIMARY KEY,
      payload LONGTEXT NOT NULL,
      updated_at TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
        ON UPDATE CURRENT_TIMESTAMP(3)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);
}

// Helper to generate initials
const getInitials = (name: string): string => {
  return name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase();
};

const normalizePatientField = (value?: string): string =>
  String(value || '').trim().toLowerCase().replace(/[^a-z0-9]/g, '');

// Helper to generate MRN
const generateMRN = (): string => {
  const num = Math.floor(1000 + Math.random() * 9000);
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const c1 = chars[Math.floor(Math.random() * 26)];
  const c2 = chars[Math.floor(Math.random() * 26)];
  return `#${num}-${c1}${c2}`;
};

// Default Seed Data
const DEFAULT_DATABASE: DatabaseSchema = {
  patients: [
    {
      id: 'p1',
      name: 'Jane Doe',
      phone: '(555) 123-4567',
      dob: '1988-05-14',
      email: 'jane@example.com',
      referralSource: 'physician',
      status: 'In Progress',
      mrn: '#1293-JD',
      avatarInitials: 'JD',
      files: []
    },
    {
      id: 'p2',
      name: 'Alex Smith',
      phone: '(555) 987-6543',
      dob: '1992-11-23',
      email: 'alex@example.com',
      referralSource: 'hospital',
      status: 'Consultation',
      mrn: '#8832-AS',
      avatarInitials: 'AS',
      files: []
    },
    {
      id: 'p3',
      name: 'Michael Johnson',
      phone: '(555) 456-7890',
      dob: '1975-02-18',
      email: 'michael@example.com',
      referralSource: 'specialist',
      status: 'Fabrication',
      mrn: '#5521-MJ',
      avatarInitials: 'MJ',
      files: []
    },
    {
      id: 'p4',
      name: 'Eleanor Vance',
      phone: '(555) 019-2834',
      dob: '1945-04-12',
      email: 'eleanor@example.com',
      referralSource: 'specialist',
      status: 'Fabrication',
      mrn: '#8492-AX',
      avatarInitials: 'EV',
      files: [
        { id: 'f1', name: 'Prescription_DrThorne.pdf', type: 'pdf', date: 'Oct 12, 2023', size: '1.2 MB' },
        { id: 'f2', name: 'Scan_Insurance_Card_Front.jpg', type: 'jpg', date: 'Oct 10, 2023', size: '3.4 MB' },
        { id: 'f3', name: 'Scan_Insurance_Card_Back.jpg', type: 'jpg', date: 'Oct 10, 2023', size: '3.1 MB' },
        { id: 'f4', name: 'Clinical_Notes_Orthopedics.pdf', type: 'pdf', date: 'Oct 05, 2023', size: '5.8 MB' }
      ]
    },
    {
      id: 'p5',
      name: 'Robert Chen',
      phone: '(555) 888-2321',
      dob: '1994-08-12',
      email: 'robert@example.com',
      referralSource: 'physician',
      status: 'New Referral',
      mrn: '#899-23A',
      avatarInitials: 'RC',
      files: []
    },
    {
      id: 'p6',
      name: 'Maria Gonzalez',
      phone: '(555) 777-1111',
      dob: '1985-03-24',
      email: 'maria@example.com',
      referralSource: 'physician',
      status: 'New Referral',
      mrn: '#442-90B',
      avatarInitials: 'MG',
      files: []
    },
    {
      id: 'p7',
      name: 'James Wilson',
      phone: '(555) 222-3333',
      dob: '1962-09-15',
      email: 'james@example.com',
      referralSource: 'specialist',
      status: 'Waiting for Rx',
      mrn: '#112-88C',
      avatarInitials: 'JW',
      files: []
    },
    {
      id: 'p8',
      name: 'Elena Davis',
      phone: '(555) 345-6789',
      dob: '1978-01-22',
      email: 'elena@example.com',
      referralSource: 'physician',
      status: 'Auth Pending',
      mrn: '#771-44D',
      avatarInitials: 'ED',
      files: []
    },
    {
      id: 'p9',
      name: 'Thomas Wright',
      phone: '(555) 543-2109',
      dob: '1950-10-09',
      email: 'thomas@example.com',
      referralSource: 'hospital',
      status: 'Auth Pending',
      mrn: '#220-91E',
      avatarInitials: 'TW',
      files: []
    }
  ],
  appointments: [
    {
      id: 'a1',
      patientName: 'John Smith',
      time: '09:00 AM',
      type: 'Initial Evaluation - AFO',
      status: 'Checked In',
      initials: 'JS'
    },
    {
      id: 'a2',
      patientName: 'Emma Watson',
      time: '11:30 AM',
      type: 'Fitting & Delivery',
      status: 'Scheduled',
      initials: 'EW'
    },
    {
      id: 'a3',
      patientName: 'Marcus Thorne',
      time: '01:00 PM',
      type: 'Follow-up Alignment Check',
      status: 'Scheduled',
      initials: 'MT'
    },
    {
      id: 'a4',
      patientName: 'Elena Rodriguez',
      time: '03:30 PM',
      type: 'AFO Adjustment',
      status: 'Scheduled',
      initials: 'ER'
    }
  ],
  authorizations: [
    {
      id: 'au1',
      patientName: 'Sarah Jenkins',
      device: 'AFO - Right Ankle',
      status: 'Pending',
      submittedDate: 'Oct 12, 2023',
      daysWaiting: 14,
      payer: 'BlueCross BlueShield',
      notes: 'Initial claim submittal. Patient has prior auth history with BCBS.'
    },
    {
      id: 'au2',
      patientName: 'Marcus Thorne',
      device: 'Trans-tibial Prosthesis',
      status: 'Approved',
      submittedDate: 'Oct 20, 2023',
      daysWaiting: 6,
      payer: 'Medicare',
      authNumber: 'A-99231',
      notes: 'LMN signed and loaded. Approved on first review.'
    },
    {
      id: 'au3',
      patientName: 'Elena Rodriguez',
      device: 'Custom KAFO',
      status: 'Pending', // In Review in visual but maps to pending state with notes
      submittedDate: 'Oct 24, 2023',
      daysWaiting: 2,
      payer: 'Aetna',
      notes: 'Awaiting Response'
    }
  ],
  claims: [
    {
      id: 'c1',
      claimNumber: 'INV-2023-0891',
      patientName: 'Sarah Jenkins',
      payer: 'Medicare',
      doctor: 'Dr. Deepak Kumar Bhardwaj',
      amount: 2450.00,
      date: 'Oct 25',
      status: 'Billed'
    },
    {
      id: 'c2',
      claimNumber: 'INV-2023-0890',
      patientName: 'David Chen',
      payer: 'BlueCross',
      doctor: 'Dr. David Chen',
      amount: 1120.00,
      date: 'Oct 24',
      status: 'Billed'
    },
    {
      id: 'c3',
      claimNumber: 'INV-2023-0889',
      patientName: 'Robert Vance',
      payer: 'Aetna',
      doctor: 'Dr. Robert Vance',
      amount: 3800.00,
      date: 'Oct 22',
      status: 'Billed'
    }
  ],
  settings: {
    clinicName: 'Genfinity O&P',
    primaryAddress: '123 Prosthetics Way, Suite 400',
    contactPhone: '(555) 123-4567',
    supportEmail: 'support@genfinity.com',
    requirePin: true,
    pinCode: '1234',
    appearance: 'light'
  },
  fabrication: [
    {
      id: 'fab1',
      patientName: 'Eleanor Vance',
      device: 'Custom AFO Brace - Thermoforming',
      stage: 'Thermoforming',
      priority: 'Standard',
      techNotes: 'Vacuum pressure looks stable. Cast corrected +1deg dorsiflexion.',
      updatedAt: 'Oct 26'
    },
    {
      id: 'fab2',
      patientName: 'Michael Johnson',
      device: 'Trans-tibial Socket Layout',
      stage: 'Layout',
      priority: 'Urgent',
      techNotes: 'Needs custom carbon fiber reinforcement layout.',
      updatedAt: 'Oct 26'
    },
    {
      id: 'fab3',
      patientName: 'Jane Doe',
      device: 'KAFO Joint Assembly',
      stage: 'Assembly',
      priority: 'Standard',
      techNotes: 'Becker joints checked and lubricated. Ready for final straps.',
      updatedAt: 'Oct 25'
    }
  ],
  alerts: [
    {
      id: 'al1',
      type: 'warning',
      title: 'Auth Expiring Soon',
      message: "Michael Brown's authorization expires in 3 days.",
      actionText: 'Review Auth',
      actionTarget: 'auth'
    },
    {
      id: 'al2',
      type: 'info',
      title: 'Missing Documentation',
      message: 'Sarah Davis needs LMN signed.',
      actionText: 'Upload Doc',
      actionTarget: 'documents'
    }
  ]
};

interface EmailAttachment {
  name: string;
  content: string;
  contentType?: string;
}

function pdfEscape(value: string): string {
  return value.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
}

function moneyForEmail(amount: number): string {
  return `$${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function buildInvoicePdf({
  patient,
  claimNumber,
  payer,
  doctor,
  amount,
  date,
  clinic,
  serviceDescription = 'Orthotic and prosthetic clinical services',
  repairDetails = '',
  paymentMethod = 'Self-pay',
  serviceTotal = amount,
  gratuity = 0,
  warrantyDays = 30
}: {
  patient: Patient;
  claimNumber: string;
  payer: string;
  doctor: string;
  amount: number;
  date: string;
  clinic: ClinicSettings;
  serviceDescription?: string;
  repairDetails?: string;
  paymentMethod?: string;
  serviceTotal?: number;
  gratuity?: number;
  warrantyDays?: number;
}): Buffer {
  const money = `$${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  const officialAddress = '18401 Burbank Blvd, Suite 215, Tarzana, CA 91356';
  const officialPhone = '(888) 552-6188';
  const officialFax = '(323) 909-8512';
  const officialEmail = 'support@genfinityoandp.com';
  const address = !clinic.primaryAddress || clinic.primaryAddress.includes('123 Prosthetics Way') ? officialAddress : clinic.primaryAddress;
  const phone = !clinic.contactPhone || clinic.contactPhone.includes('555') ? officialPhone : clinic.contactPhone;
  const email = !clinic.supportEmail || clinic.supportEmail.includes('genfinity.com') ? officialEmail : clinic.supportEmail;
  const brand = '0.70 0.04 0.02';
  const blush = '0.98 0.94 0.94';
  const ink = '0.12 0.12 0.14';
  const muted = '0.38 0.35 0.36';
  const lines = [
    { text: clinic.clinicName || 'Genfinity O&P', x: 106, y: 725, size: 19, font: 'F2', color: '1 1 1' },
    { text: address, x: 60, y: 641, size: 9, font: 'F1', color: muted },
    { text: `${phone}  |  Fax ${officialFax}  |  ${email}`, x: 60, y: 626, size: 8, font: 'F1', color: muted },
    { text: 'PAID INVOICE', x: 390, y: 725, size: 20, font: 'F2', color: brand },
    { text: `# ${claimNumber}`, x: 420, y: 706, size: 10, font: 'F1', color: muted },
    { text: `Issued ${date}`, x: 420, y: 691, size: 9, font: 'F1', color: muted },
    { text: 'PAID', x: 484, y: 633, size: 10, font: 'F2', color: '0.08 0.45 0.28' },
    { text: 'BILL TO', x: 60, y: 590, size: 9, font: 'F2', color: brand },
    { text: patient.name, x: 60, y: 569, size: 15, font: 'F2', color: ink },
    { text: `MRN ${patient.mrn || 'Not provided'}`, x: 60, y: 550, size: 9, font: 'F1', color: muted },
    { text: `DOB ${patient.dob || 'Not provided'}`, x: 188, y: 550, size: 9, font: 'F1', color: muted },
    { text: patient.address || 'Address not provided', x: 60, y: 533, size: 9, font: 'F1', color: muted },
    { text: 'SERVICE SUMMARY', x: 60, y: 484, size: 9, font: 'F2', color: brand },
    { text: 'Description', x: 60, y: 456, size: 9, font: 'F2', color: muted },
    { text: 'Amount', x: 475, y: 456, size: 9, font: 'F2', color: muted },
    { text: serviceDescription.slice(0, 68), x: 60, y: 427, size: 10, font: 'F1', color: ink },
    { text: moneyForEmail(serviceTotal), x: 475, y: 427, size: 10, font: 'F2', color: ink },
    { text: `Payer: ${payer || 'Self-pay'}`, x: 60, y: 397, size: 9, font: 'F1', color: muted },
    { text: `Clinician: ${doctor || 'Not assigned'}`, x: 60, y: 381, size: 9, font: 'F1', color: muted },
    { text: `Payment method: ${paymentMethod}`, x: 60, y: 365, size: 9, font: 'F1', color: muted },
    ...(repairDetails ? [{ text: `Details: ${repairDetails.slice(0, 82)}`, x: 60, y: 349, size: 8, font: 'F1', color: muted }] : []),
    { text: 'TOTAL PAID', x: 366, y: 326, size: 10, font: 'F2', color: muted },
    { text: money, x: 475, y: 324, size: 17, font: 'F2', color: brand },
    { text: 'Balance due: $0.00 - PAID IN FULL', x: 366, y: 288, size: 8, font: 'F2', color: '0.08 0.45 0.28' },
    ...(gratuity > 0 ? [{ text: `Includes voluntary gratuity / tip: ${moneyForEmail(gratuity)}`, x: 366, y: 306, size: 8, font: 'F1', color: muted }] : []),
    { text: 'Thank you for choosing Genfinity O&P.', x: 60, y: 236, size: 10, font: 'F2', color: ink },
    { text: `Questions? ${email}`, x: 60, y: 218, size: 9, font: 'F1', color: muted },
    { text: 'TERMS & CONDITIONS', x: 60, y: 158, size: 9, font: 'F2', color: brand },
    { text: `Payment is due according to the agreed billing arrangement. Warranty: ${warrantyDays} days on workmanship.`, x: 60, y: 142, size: 8, font: 'F1', color: muted },
    { text: 'Please retain this invoice for your records. Balances may be subject to payer review.', x: 60, y: 129, size: 8, font: 'F1', color: muted },
    { text: 'Services, adjustments, and warranties are provided under the clinic policy in effect on the date of service.', x: 60, y: 116, size: 8, font: 'F1', color: muted },
    { text: 'This document is a payment receipt for the services listed above.', x: 60, y: 82, size: 8, font: 'F1', color: muted }
  ];
  const stream = [
    'q',
    '1 1 1 rg 42 672 528 78 re f',
    `${brand} rg 42 655 528 1 re f`,
    'q 150 0 0 37.5 54 692 cm /Im1 Do Q',
    `${blush} rg 42 512 528 92 re f`,
    '1 1 1 rg 42 604 528 1 re f',
    `${blush} rg 42 450 528 1 re f`,
    `${brand} rg 42 345 528 2 re f`,
    `${blush} rg 358 294 212 70 re f`,
    `${blush} rg 42 182 528 1 re f`,
    `${blush} rg 42 104 528 1 re f`,
    'Q',
    ...lines.map(line => `${line.color} rg BT /${line.font} ${line.size} Tf ${line.x} ${line.y} Td (${pdfEscape(line.text)}) Tj ET`)
  ].join('\n');
  const logoPath = [path.join(process.cwd(), 'public', 'genfinity-logo.jpg'), path.join(__dirname, 'public', 'genfinity-logo.jpg')].find(candidate => {
    try { readFileSync(candidate); return true; } catch { return false; }
  });
  const logo = logoPath ? readFileSync(logoPath) : Buffer.alloc(0);
  const objectBodies: Buffer[] = [
    Buffer.from('<< /Type /Catalog /Pages 2 0 R >>', 'ascii'),
    Buffer.from('<< /Type /Pages /Kids [3 0 R] /Count 1 >>', 'ascii'),
    Buffer.from('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> /XObject << /Im1 7 0 R >> >> /Contents 6 0 R >>', 'ascii'),
    Buffer.from('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>', 'ascii'),
    Buffer.from('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>', 'ascii'),
    Buffer.from(`<< /Length ${Buffer.byteLength(stream, 'ascii')} >>\nstream\n${stream}\nendstream`, 'ascii'),
    Buffer.concat([Buffer.from(`<< /Type /XObject /Subtype /Image /Width 1100 /Height 275 /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${logo.length} >>\nstream\n`, 'ascii'), logo, Buffer.from('\nendstream', 'ascii')])
  ];
  const chunks: Buffer[] = [Buffer.from('%PDF-1.4\n', 'ascii')];
  const offsets = [0];
  objectBodies.forEach((body, index) => {
    offsets[index + 1] = chunks.reduce((size, chunk) => size + chunk.length, 0);
    chunks.push(Buffer.from(`${index + 1} 0 obj\n`, 'ascii'), body, Buffer.from('\nendobj\n', 'ascii'));
  });
  const xrefOffset = chunks.reduce((size, chunk) => size + chunk.length, 0);
  let xref = `xref\n0 ${objectBodies.length + 1}\n0000000000 65535 f \n`;
  offsets.slice(1).forEach(offset => { xref += `${String(offset).padStart(10, '0')} 00000 n \n`; });
  xref += `trailer\n<< /Size ${objectBodies.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;
  chunks.push(Buffer.from(xref, 'ascii'));
  return Buffer.concat(chunks);
}

async function sendBrevoEmail(to: string, subject: string, body: string, attachments: EmailAttachment[] = [], htmlBody?: string): Promise<{ success: boolean; message: string; logs: string[] }> {
  const logs = [`[${new Date().toLocaleTimeString()}] Sending through Brevo transactional email API...`];
  if (!BREVO_API_KEY || !BREVO_FROM_EMAIL) {
    return { success: false, message: 'Brevo API is not configured. Add BREVO_API_KEY and BREVO_FROM_EMAIL.', logs };
  }
  try {
    const response = await fetch('https://api.brevo.com/v3/smtp/email', {
      method: 'POST',
      headers: { accept: 'application/json', 'api-key': BREVO_API_KEY, 'content-type': 'application/json' },
      body: JSON.stringify({
        sender: { email: BREVO_FROM_EMAIL, name: BREVO_SENDER_NAME },
        to: [{ email: to }],
        subject,
        textContent: body,
        htmlContent: htmlBody || `<div style="font-family:Arial,sans-serif;white-space:pre-wrap">${body.replace(/[&<>]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[char] || char))}</div>`,
        ...(attachments.length ? { attachment: attachments.map(({ name, content }) => ({ name, content })) } : {}),
        ...(BREVO_REPLY_TO ? { replyTo: { email: BREVO_REPLY_TO } } : {})
      })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) return { success: false, message: data.message || `Brevo returned HTTP ${response.status}.`, logs };
    logs.push(`[${new Date().toLocaleTimeString()}] Brevo accepted the message${data.messageId ? ` (${data.messageId})` : ''}.`);
    return { success: true, message: data.messageId ? `Email sent through Brevo. Message ID: ${data.messageId}` : 'Email sent through Brevo.', logs };
  } catch (error: any) {
    return { success: false, message: `Brevo error: ${error.message}`, logs };
  }
}

// Email Dispatch & Connection Diagnostics Helper
async function sendEmail(smtp: SmtpConfig, to: string, subject: string, body: string, attachments: EmailAttachment[] = [], htmlBody?: string): Promise<{ success: boolean; message: string; logs: string[] }> {
  if (BREVO_API_KEY && BREVO_FROM_EMAIL) return sendBrevoEmail(to, subject, body, attachments, htmlBody);
  const logs: string[] = [];
  
  // Sanitize host string: remove protocols like https://, http://, smtp://, ://, and trailing slashes/ports
  let sanitizedHost = (smtp.host || '').trim();
  sanitizedHost = sanitizedHost.replace(/^(https?:\/\/|http:\/\/|smtp:\/\/|:\/*)+/i, '');
  sanitizedHost = sanitizedHost.split('/')[0].split(':')[0].trim();

  // Auto-correct common web domains to their standard outgoing SMTP server hostnames
  if (sanitizedHost.toLowerCase() === 'gmail.com') sanitizedHost = 'smtp.gmail.com';
  if (sanitizedHost.toLowerCase() === 'outlook.com' || sanitizedHost.toLowerCase() === 'office365.com') sanitizedHost = 'smtp.office365.com';
  if (sanitizedHost.toLowerCase() === 'yahoo.com') sanitizedHost = 'smtp.mail.yahoo.com';

  logs.push(`[${new Date().toLocaleTimeString()}] Initiating SMTP connection handshake with ${sanitizedHost || 'unspecified'}:${smtp.port}...`);
  
  // Treat standard placeholder hosts as simulation so it works out-of-the-box
  const isSimulation = !sanitizedHost || !smtp.user || !smtp.pass;

  if (isSimulation) {
    return { success: false, message: 'Email provider is not configured. Add the Brevo API key and verified sender.', logs };
  }

  try {
    logs.push(`[${new Date().toLocaleTimeString()}] Attempting real secure SMTP connection via nodemailer...`);
    const transporter = nodemailer.createTransport({
      host: sanitizedHost,
      port: Number(smtp.port),
      secure: smtp.secure,
      auth: {
        user: smtp.user,
        pass: smtp.pass,
      },
      tls: {
        rejectUnauthorized: false
      }
    });

    logs.push(`[${new Date().toLocaleTimeString()}] Verifying SMTP credentials with remote host...`);
    await transporter.verify();
    logs.push(`[${new Date().toLocaleTimeString()}] SMTP verification successful. Sending message...`);

    const info = await transporter.sendMail({
      from: `"${smtp.senderName}" <${smtp.fromEmail}>`,
      replyTo: smtp.replyTo || smtp.fromEmail,
      to,
      subject,
      text: body,
      html: htmlBody,
      attachments: attachments.map(attachment => ({ filename: attachment.name, content: Buffer.from(attachment.content, 'base64'), contentType: attachment.contentType })),
    });

    logs.push(`[${new Date().toLocaleTimeString()}] Email sent successfully! MessageId: ${info.messageId}`);
    return { success: true, message: `Real email sent! MessageId: ${info.messageId}`, logs };
  } catch (error: any) {
    logs.push(`[${new Date().toLocaleTimeString()}] SMTP Connection or Authentication Error: ${error.message}`);
    return { success: false, message: `SMTP Error: ${error.message}`, logs };
  }
}

const appointmentClinic = {
  name: 'Genfinity O&P',
  provider: 'Deepak Kumar Bhardwaj',
  address: '18401 Burbank Blvd, Suite 215, Tarzana, CA 91356',
  phone: '(888) 552-6188',
  email: 'support@genfinityoandp.com',
  directions: 'https://maps.app.goo.gl/BubTETC1SF6pHEbQ8'
};

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char] || char));
}

function appointmentFirstName(name: string): string {
  return name.trim().split(/\s+/)[0] || 'there';
}

function appointmentDateLabel(value: string): string {
  const parsed = new Date(`${value}T12:00:00`);
  return Number.isNaN(parsed.getTime()) ? value : parsed.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
}

function appointmentSms(patient: Patient, date: string, time: string): string {
  return `Hi ${appointmentFirstName(patient.name)}, your appointment with ${appointmentClinic.provider} at ${appointmentClinic.name} is confirmed.\n📅 ${appointmentDateLabel(date)} at ${time}\n📍 ${appointmentClinic.address}\n🗺️ Directions: ${appointmentClinic.directions}\nNeed to reschedule? Call us at ${appointmentClinic.phone}.\n— ${appointmentClinic.name}`;
}

function appointmentEmail(patient: Patient, date: string, time: string): { subject: string; text: string; html: string } {
  const firstName = escapeHtml(appointmentFirstName(patient.name));
  const dateLabel = escapeHtml(appointmentDateLabel(date));
  const safeTime = escapeHtml(time);
  const logoPath = [path.join(process.cwd(), 'public', 'genfinity-logo.jpg'), path.join(__dirname, 'public', 'genfinity-logo.jpg')].find(candidate => {
    try { readFileSync(candidate); return true; } catch { return false; }
  });
  const logo = logoPath ? `data:image/jpeg;base64,${readFileSync(logoPath).toString('base64')}` : '';
  const subject = `Appointment confirmed - ${appointmentClinic.name}`;
  const text = `Hi ${appointmentFirstName(patient.name)},\n\nYour appointment with ${appointmentClinic.provider} at ${appointmentClinic.name} has been successfully booked.\n\nAPPOINTMENT DETAILS\nDate: ${appointmentDateLabel(date)}\nTime: ${time}\nProvider: ${appointmentClinic.provider}\nLocation: ${appointmentClinic.name}\nAddress: ${appointmentClinic.address}\nGet Directions: ${appointmentClinic.directions}\n\nIf you need to reschedule your appointment or have any questions, please call us at ${appointmentClinic.phone}.\n\nWe look forward to seeing you!\n\nWarm regards,\n${appointmentClinic.name}\n${appointmentClinic.address}\n${appointmentClinic.phone}\n${appointmentClinic.email}`;
  const html = `<!doctype html><html><body style="margin:0;background:#f5f7fa;font-family:Arial,Helvetica,sans-serif;color:#202124"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f5f7fa;padding:32px 12px"><tr><td align="center"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:620px;background:#fff;border-radius:18px;overflow:hidden;box-shadow:0 8px 30px rgba(31,41,55,.10)"><tr><td style="background:#8f0011;padding:24px 32px;text-align:center">${logo ? `<img src="${logo}" alt="${appointmentClinic.name}" width="180" style="display:inline-block;max-width:180px;height:auto;background:#fff;border-radius:8px;padding:6px">` : `<div style="font-size:24px;font-weight:700;color:#fff">${appointmentClinic.name}</div>`}</td></tr><tr><td style="padding:36px 40px 12px"><p style="margin:0;color:#8f0011;font-size:12px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase">Appointment confirmed</p><h1 style="margin:10px 0 12px;font-size:28px;line-height:1.2;color:#202124">Hi ${firstName},</h1><p style="margin:0;font-size:16px;line-height:1.7">Your appointment with <strong>${appointmentClinic.provider}</strong> at <strong>${appointmentClinic.name}</strong> has been successfully booked.</p></td></tr><tr><td style="padding:18px 40px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#fff7f7;border:1px solid #f0d8db;border-radius:12px"><tr><td style="padding:22px 24px"><h2 style="margin:0 0 16px;font-size:16px;color:#8f0011">Appointment details</h2><p style="margin:8px 0;font-size:14px"><strong>Date:</strong> ${dateLabel}</p><p style="margin:8px 0;font-size:14px"><strong>Time:</strong> ${safeTime}</p><p style="margin:8px 0;font-size:14px"><strong>Provider:</strong> ${appointmentClinic.provider}</p><p style="margin:8px 0;font-size:14px"><strong>Location:</strong> ${appointmentClinic.name}</p><p style="margin:8px 0;font-size:14px"><strong>Address:</strong> ${appointmentClinic.address}</p><p style="margin:18px 0 0"><a href="${appointmentClinic.directions}" style="display:inline-block;background:#8f0011;color:#fff;text-decoration:none;border-radius:999px;padding:11px 18px;font-size:13px;font-weight:700">🗺️ Get directions</a></p></td></tr></table></td></tr><tr><td style="padding:10px 40px 34px"><p style="margin:0;font-size:15px;line-height:1.7">If you need to reschedule your appointment or have any questions, please call us at <strong>${appointmentClinic.phone}</strong>.</p><p style="margin:24px 0 0;font-size:15px;line-height:1.7">We look forward to seeing you!</p><p style="margin:24px 0 0;font-size:14px;line-height:1.6">Warm regards,<br><strong>${appointmentClinic.name}</strong><br>${appointmentClinic.address}<br>${appointmentClinic.phone}<br><a href="mailto:${appointmentClinic.email}" style="color:#8f0011">${appointmentClinic.email}</a></p></td></tr><tr><td style="background:#fafafa;padding:18px 40px;text-align:center;color:#6b7280;font-size:11px;line-height:1.5">This is an automated appointment confirmation from ${appointmentClinic.name}.</td></tr></table></td></tr></table></body></html>`;
  return { subject, text, html };
}

async function getRingCentralAccessToken(): Promise<string> {
  if (ringCentralToken && ringCentralToken.expiresAt > Date.now() + 30_000) return ringCentralToken.accessToken;
  if (!RC_APP_CLIENT_ID || !RC_APP_CLIENT_SECRET || !RC_USER_JWT) throw new Error('RingCentral SMS is not configured. Add the RingCentral app credentials and user JWT.');
  const credentials = Buffer.from(`${RC_APP_CLIENT_ID}:${RC_APP_CLIENT_SECRET}`).toString('base64');
  const response = await fetch(`${RINGCENTRAL_SERVER_URL}/restapi/oauth/token`, {
    method: 'POST',
    headers: { Authorization: `Basic ${credentials}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: RC_USER_JWT })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.access_token) {
    const providerError = [data.error_description, data.message, data.errorCode].filter(Boolean).join(' — ');
    const invalidClient = /invalid client application|invalid client credentials/i.test(providerError);
    const detail = invalidClient
      ? `RingCentral rejected the client application credentials for ${RINGCENTRAL_SERVER_URL}. Check that RC_APP_CLIENT_ID and RC_APP_CLIENT_SECRET belong to the same RingCentral app and environment (production vs sandbox), then redeploy.`
      : providerError || `RingCentral authentication failed (HTTP ${response.status}).`;
    throw new Error(detail);
  }
  ringCentralToken = { accessToken: data.access_token, expiresAt: Date.now() + Number(data.expires_in || 3600) * 1000 };
  return data.access_token;
}

async function sendRingCentralSms(to: string, text: string): Promise<{ messageId?: string }> {
  if (!RC_FROM_PHONE_NUMBER) throw new Error('RingCentral SMS is not configured. Add RC_FROM_PHONE_NUMBER.');
  const accessToken = await getRingCentralAccessToken();
  const response = await fetch(`${RINGCENTRAL_SERVER_URL}/restapi/v1.0/account/~/extension/~/sms`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: { phoneNumber: RC_FROM_PHONE_NUMBER }, to: [{ phoneNumber: to }], text })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || `RingCentral rejected the SMS (HTTP ${response.status}).`);
  return { messageId: data.id ? String(data.id) : undefined };
}

// Database Accessor Helpers
async function readDatabase(): Promise<DatabaseSchema> {
  let db: DatabaseSchema;
  const pool = useLocalJsonDatabase ? null : getMysqlPool();

  if (!pool) {
    if (!isLocalDevelopment) {
      throw new Error('Hostinger MySQL is not configured. Clinical data access is disabled.');
    }
    db = JSON.parse(await fs.readFile(LOCAL_DATABASE_PATH, 'utf8'));
  } else {
    await ensureMysqlSchema(pool);
    const [rows] = await pool.execute<any[]>(
      'SELECT payload FROM app_state WHERE state_key = ? LIMIT 1',
      ['clinic']
    );
    if (rows.length) {
      db = JSON.parse(rows[0].payload);
    } else {
      db = JSON.parse(JSON.stringify(DEFAULT_DATABASE));
      await pool.execute(
        'INSERT INTO app_state (state_key, payload) VALUES (?, ?)',
        ['clinic', JSON.stringify(db)]
      );
    }
  }

  // Ensure default Email structures exist
  if (!db.smtpConfig) {
    db.smtpConfig = {
      host: BREVO_SMTP_HOST,
      port: 587,
      user: '',
      pass: '',
      secure: false,
      fromEmail: 'notifications@genfinityortho.com',
      senderName: 'Genfinity Orthotics & Prosthetics Clinic'
    };
  }

  if (!db.emailTemplates || db.emailTemplates.length === 0) {
    db.emailTemplates = [
      {
        id: 'temp_appt',
        name: 'Appointment Confirmed & Instructions',
        subject: 'Appointment Confirmed - {clinicName}',
        triggerEvent: 'appointment_booked',
        body: `Dear {patientName},

Your upcoming appointment for {appointmentType} at {clinicName} is confirmed!

📅 Date/Time: {appointmentTime}
📍 Location: {clinicAddress}

O&P Clinical Guidance & Preparations:
1. For lower-limb orthotic fittings (AFO, KAFO, foot orthoses): Please bring or wear stable, lace-up athletic shoes with clean socks.
2. For prosthetic fittings (trans-tibial, trans-femoral evaluations): Please wear loose-fitting clothing or shorts to ensure our clinical specialists can perform precise alignment checks.
3. Documentation: Remember to bring your active insurance card, valid photo ID, and the signed physician prescription if you have not already submitted it.

If you have any questions or need to reschedule, please contact our care team at {clinicPhone} or email us at {supportEmail}.

Warm regards,
Clinical Patient Care
{clinicName}`
      },
      {
        id: 'temp_fab',
        name: 'Custom Device Fabrication Progress',
        subject: 'Custom Device Fabrication Update - {clinicName}',
        triggerEvent: 'fabrication_status_changed',
        body: `Dear {patientName},

We are excited to share an update on your custom-fabricated clinical device ({deviceName})!

🛠️ Progress Milestone: {fabricationStage}

Our specialized clinical laboratory is hand-crafting your device with the highest standard of bio-mechanical alignment. Each modification, thermoforming, and grinding process is performed by our certified technicians to meet your precise anatomical prescription.

What happens next?
Once the fabrication is fully completed and passes our multi-point Quality Assurance (QA) inspection, we will contact you immediately to schedule your custom fitting and delivery appointment!

Best regards,
Lab Operations & Technical Staff
{clinicName}`
      },
      {
        id: 'temp_auth',
        name: 'Insurance Authorization Approved',
        subject: 'Good News! Insurance Authorization Approved - {clinicName}',
        triggerEvent: 'auth_status_approved',
        body: `Dear {patientName},

Excellent news! We have received formal insurance authorization approval from {payerName} for your custom device ({deviceName}).

📝 Authorization Details:
- Status: APPROVED & ACTIVE
- Auth Reference: {authNumber}

This approval clears our team to proceed with hand-crafting your custom device. Our technical lab has been notified, and materials are being prepared to begin fabrication immediately.

Our administrative team will keep you updated as the device proceeds through development. If you have any immediate questions, feel free to reach us at {clinicPhone}.

Warm regards,
Clinical Care Coordination
{clinicName}`
      },
      {
        id: 'temp_bill',
        name: 'Invoice Statement Alert',
        subject: 'Statement of Account & Patient Co-Pay Statement - {clinicName}',
        triggerEvent: 'invoice_billed',
        body: `Dear {patientName},

Please find summary details of the statement from your recent orthotic/prosthetic treatment.

📄 Account Statement Summary:
- Invoice Number: {claimNumber}
- Insurer Group: {payerName}
- Patient Co-Pay Balance: \${claimAmount}

You can pay this balance securely inside our clinical portal or at our reception desk during your next alignment fitting.

If you have questions about your billing, deductibles, or would like to coordinate a flexible payment schedule, please call our billing desk at {clinicPhone} or reply to {supportEmail}.

Sincerely,
Billing & Patient Accounts
{clinicName}`
      }
    ];
  }

  if (!db.emailLogs) {
    db.emailLogs = [
      {
        id: 'log_1',
        recipientEmail: 'eleanor@example.com',
        patientName: 'Eleanor Vance',
        subject: 'Custom Device Fabrication Update - Genfinity O&P',
        body: 'Dear Eleanor Vance,\n\nWe are excited to share an update on your custom-fabricated clinical device (Custom AFO Brace)... Progress Milestone: Thermoforming...',
        templateName: 'Custom Device Fabrication Progress',
        sentAt: 'Jul 14, 2026, 02:45 PM',
        status: 'Sent'
      },
      {
        id: 'log_2',
        recipientEmail: 'maria@example.com',
        patientName: 'Maria Gonzalez',
        subject: 'Appointment Confirmed - Genfinity O&P',
        body: 'Dear Maria Gonzalez,\n\nYour upcoming appointment for Initial Evaluation - AFO at Genfinity O&P is confirmed!\n\nDate/Time: 09:00 AM...',
        templateName: 'Appointment Confirmed & Instructions',
        sentAt: 'Jul 14, 2026, 11:15 AM',
        status: 'Sent'
      }
    ];
  }

  // Patient is the source of truth. Remove legacy orphan rows created before
  // linked-record cascading was introduced.
  const patientById = new Map(db.patients.map(patient => [patient.id, patient]));
  const patientByName = new Map(db.patients.map(patient => [patient.name.trim().toLowerCase(), patient]));
  const normalizeLinkedItems = <T extends { patientId?: string; patientName: string }>(items: T[]): T[] =>
    items.flatMap(item => {
      const patient = (item.patientId && patientById.get(item.patientId))
        || patientByName.get(item.patientName.trim().toLowerCase());
      return patient ? [{ ...item, patientId: patient.id, patientName: patient.name }] : [];
    });
  const previousLinkedState = JSON.stringify([db.appointments, db.authorizations, db.claims, db.fabrication]);
  db.appointments = normalizeLinkedItems(db.appointments);
  db.authorizations = normalizeLinkedItems(db.authorizations);
  db.claims = normalizeLinkedItems(db.claims);
  db.fabrication = normalizeLinkedItems(db.fabrication);
  const nextLinkedState = JSON.stringify([db.appointments, db.authorizations, db.claims, db.fabrication]);

  if (nextLinkedState !== previousLinkedState) {
    if (pool) {
      await pool.execute(
        `INSERT INTO app_state (state_key, payload) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE payload = VALUES(payload)`,
        ['clinic', JSON.stringify(db)]
      );
    } else if (useLocalJsonDatabase) {
      await fs.writeFile(LOCAL_DATABASE_PATH, JSON.stringify(db, null, 2));
    }
  }

  return db;
}

async function writeDatabase(db: DatabaseSchema): Promise<void> {
  const pool = useLocalJsonDatabase ? null : getMysqlPool();
  if (!pool) {
    if (!isLocalDevelopment) {
      throw new Error('Hostinger MySQL is not configured. Clinical data writes are disabled.');
    }
    await fs.writeFile(LOCAL_DATABASE_PATH, JSON.stringify(db, null, 2));
    return;
  }
  await ensureMysqlSchema(pool);
  await pool.execute(
    `INSERT INTO app_state (state_key, payload) VALUES (?, ?)
     ON DUPLICATE KEY UPDATE payload = VALUES(payload)`,
    ['clinic', JSON.stringify(db)]
  );
}

async function startServer() {
  const app = express();
  const requestedPort = Number(process.env.PORT || 3000);
  // Keep local development usable when a previous Genfinity process is still
  // holding port 3000. Hostinger must continue to use its assigned PORT.
  const PORT = process.env.NODE_ENV === 'development'
    ? await findAvailablePort(requestedPort)
    : requestedPort;

  app.disable('x-powered-by');
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));

  // A temporary deployment may contain clinical data, so protect the entire
  // site at the server boundary until a full identity provider is connected.
  if (process.env.ACCESS_PASSWORD) {
    const expectedUser = process.env.ACCESS_USERNAME || 'genfinity';
    const expectedPassword = process.env.ACCESS_PASSWORD;
    const sessionToken = createHmac('sha256', expectedPassword).update('genfinity-session').digest('hex');
    const accessPage = (invalid = false) => `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Genfinity Portal Access</title><style>
body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f4f7fb;font:16px system-ui;color:#172033}
form{width:min(360px,calc(100% - 48px));background:#fff;padding:32px;border-radius:18px;box-shadow:0 16px 50px #1720331a}
h1{font-size:22px;margin:0 0 8px}p{color:#5d6778;font-size:14px}input,button{box-sizing:border-box;width:100%;padding:12px 14px;border-radius:10px;font:inherit}
input{border:1px solid #ccd3df;margin:12px 0}button{border:0;background:#075e54;color:#fff;font-weight:700;cursor:pointer}.error{color:#b42318}
</style></head><body><form method="post" action="/_access"><h1>Genfinity Portal</h1><p>Enter the temporary deployment password to continue.</p>
${invalid ? '<p class="error">Incorrect password. Please try again.</p>' : ''}<input type="password" name="password" autocomplete="current-password" required autofocus>
<button type="submit">Open portal</button></form></body></html>`;

    app.get('/_access', (_req, res) => res.type('html').send(accessPage()));
    app.post('/_access', (req, res) => {
      const supplied = Buffer.from(String(req.body.password || ''));
      const expected = Buffer.from(expectedPassword);
      if (supplied.length !== expected.length || !timingSafeEqual(supplied, expected)) {
        return res.status(403).type('html').send(accessPage(true));
      }
      res.setHeader('Set-Cookie', `genfinity_access=${sessionToken}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=28800`);
      return res.type('html').send('<!doctype html><meta charset="utf-8"><title>Opening portal</title><script>location.replace("/")</script><p>Access granted. <a href="/">Open the portal</a>.</p>');
    });
    app.get('/_logout', (_req, res) => {
      res.setHeader('Set-Cookie', 'genfinity_access=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0');
      res.type('html').send(accessPage());
    });

    app.use((req, res, next) => {
      const cookieAuthenticated = (req.headers.cookie || '')
        .split(';')
        .map(value => value.trim())
        .includes(`genfinity_access=${sessionToken}`);
      const authorization = req.headers.authorization || '';
      const encoded = authorization.startsWith('Basic ') ? authorization.slice(6) : '';
      let suppliedUser = '';
      let suppliedPassword = '';
      try {
        [suppliedUser, suppliedPassword] = Buffer.from(encoded, 'base64').toString('utf8').split(':', 2);
      } catch {
        // Treat malformed authorization as unauthenticated.
      }
      suppliedUser = suppliedUser || '';
      suppliedPassword = suppliedPassword || '';

      const userMatches = suppliedUser === expectedUser;
      const supplied = Buffer.from(suppliedPassword);
      const expected = Buffer.from(expectedPassword);
      const passwordMatches = supplied.length === expected.length && timingSafeEqual(supplied, expected);
      if (!cookieAuthenticated && (!userMatches || !passwordMatches)) {
        if (req.method === 'GET') return res.status(200).type('html').send(accessPage());
        return res.status(403).json({ error: 'Authentication required' });
      }
      next();
    });
  }

  app.use('/api', (_req, res, next) => {
    res.setHeader('Cache-Control', 'no-store');
    next();
  });

  // Browsers request this automatically. Return a deliberate empty response
  // until a branded icon is configured instead of logging a misleading 404.
  app.get('/favicon.ico', (_req, res) => res.status(204).end());

  // API Routes
  app.get('/api/hostinger-status', async (req, res) => {
    let mysqlReady = false;
    try {
      const startTime = Date.now();
      await fs.mkdir(PRIVATE_STORAGE_PATH, { recursive: true });
      const probePath = path.join(PRIVATE_STORAGE_PATH, `.genfinity_probe_${process.pid}.txt`);
      const probeValue = `ok:${Date.now()}`;
      await fs.writeFile(probePath, probeValue, 'utf-8');
      const readBack = await fs.readFile(probePath, 'utf-8');
      await fs.unlink(probePath);
      const pool = useLocalJsonDatabase ? null : getMysqlPool();
      if (pool) {
        await ensureMysqlSchema(pool);
        await pool.query('SELECT 1');
        mysqlReady = true;
      }
      if (useLocalJsonDatabase) mysqlReady = true;
      const latencyMs = Date.now() - startTime;
      res.json({
        ready: readBack === probeValue && mysqlReady,
        latencyMs,
        runtime: process.version,
        persistence: useLocalJsonDatabase ? 'local-json' : 'mysql',
        database: pool ? MYSQL_DATABASE : null,
        privateStoragePath: PRIVATE_STORAGE_PATH,
        issues: [
          ...(readBack === probeValue ? [] : ['Private storage probe readback mismatch']),
          ...(mysqlReady ? [] : ['Hostinger MySQL environment variables are missing'])
        ]
      });
    } catch (err: any) {
      res.json({
        ready: false,
        issues: [mysqlErrorMessage(err), ...(mysqlErrorHint(err) ? [mysqlErrorHint(err)] : [])],
        privateStoragePath: PRIVATE_STORAGE_PATH,
        database: MYSQL_DATABASE || null,
        mysql: {
          configured: mysqlConfigured,
          reachable: mysqlReady,
          code: err?.code || 'UNKNOWN'
        }
      });
    }
  });

  // --- Email Notification Suite API Routes ---
  app.get('/api/email/config', async (req, res) => {
    try {
      const db = await readDatabase();
      res.json({
        smtpConfig: db.smtpConfig ? { ...db.smtpConfig, pass: db.smtpConfig.pass ? '********' : '' } : undefined,
        provider: BREVO_API_KEY && BREVO_FROM_EMAIL ? 'Brevo API' : 'SMTP fallback',
        brevoConfigured: Boolean(BREVO_API_KEY && BREVO_FROM_EMAIL),
        emailTemplates: db.emailTemplates,
        emailLogs: db.emailLogs
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put('/api/email/config', async (req, res) => {
    try {
      const { smtpConfig, emailTemplates } = req.body;
      const db = await readDatabase();
      if (smtpConfig) {
        const existingPassword = db.smtpConfig?.pass || '';
        db.smtpConfig = {
          ...db.smtpConfig,
          ...smtpConfig,
          pass: !smtpConfig.pass || smtpConfig.pass === '********' ? existingPassword : smtpConfig.pass
        };
      }
      if (emailTemplates) db.emailTemplates = emailTemplates;
      await writeDatabase(db);
      res.json({
        success: true,
        smtpConfig: db.smtpConfig ? { ...db.smtpConfig, pass: db.smtpConfig.pass ? '********' : '' } : undefined,
        emailTemplates: db.emailTemplates
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/email/test-connection', async (req, res) => {
    try {
      const { smtpConfig } = req.body;
      const savedConfig = (await readDatabase()).smtpConfig;
      const config = smtpConfig
        ? { ...savedConfig, ...smtpConfig, pass: !smtpConfig.pass || smtpConfig.pass === '********' ? savedConfig?.pass : smtpConfig.pass }
        : savedConfig;
      if (!config) {
        return res.status(400).json({ success: false, message: 'SMTP configuration is missing.' });
      }

      const logs: string[] = [];
      logs.push(`[${new Date().toLocaleTimeString()}] Testing SMTP Server: smtp://${config.host}:${config.port}...`);
      
      const isDummy = !config.host || !config.user || !config.pass;
      if (isDummy) {
        return res.json({ success: false, message: 'Brevo email credentials are not configured.', logs });
      }

      const transporter = nodemailer.createTransport({
        host: config.host,
        port: Number(config.port),
        secure: config.secure,
        auth: {
          user: config.user,
          pass: config.pass,
        },
        tls: {
          rejectUnauthorized: false
        }
      });

      logs.push(`[${new Date().toLocaleTimeString()}] Verification query dispatched to host...`);
      await transporter.verify();
      logs.push(`[${new Date().toLocaleTimeString()}] SMTP Handshake Success. Host is ready to route outbound clinical mail.`);

      res.json({
        success: true,
        message: 'SMTP credentials verified successfully! Connection is active.',
        logs
      });
    } catch (err: any) {
      res.json({
        success: false,
        message: err.message,
        logs: [
          `[${new Date().toLocaleTimeString()}] SMTP Connection Handshake Failed.`,
          `[${new Date().toLocaleTimeString()}] Reason: ${err.message}`
        ]
      });
    }
  });

  app.post('/api/email/send-test', async (req, res) => {
    try {
      const { smtpConfig, testEmail } = req.body;
      const db = await readDatabase();
      const config = smtpConfig
        ? { ...db.smtpConfig, ...smtpConfig, pass: !smtpConfig.pass || smtpConfig.pass === '********' ? db.smtpConfig?.pass : smtpConfig.pass }
        : db.smtpConfig;
      const targetEmail = testEmail || db.settings.supportEmail || 'test@example.com';

      if (!config) {
        return res.status(400).json({ error: 'SMTP configuration missing.' });
      }

      const testSubject = `Clinical Portal connection test - ${db.settings.clinicName}`;
      const testBody = `Hello! This is a test message confirming that your custom SMTP email notifications suite is fully active and connected to ${db.settings.clinicName}.

You are ready to dispatch patient reminders, fabrication status updates, and insurance authorization approvals automatically from the Genfinity Clinical Portal!

Timestamp: ${new Date().toLocaleString()}
Clinical Portal Support Team`;

      const result = await sendEmail(config, targetEmail, testSubject, testBody);

      const newLog: EmailLog = {
        id: `log_${Date.now()}`,
        recipientEmail: targetEmail,
        patientName: 'Test Administrator',
        subject: testSubject,
        body: testBody,
        templateName: 'Manual SMTP Connection Test',
        sentAt: new Date().toLocaleString('en-US', { month: 'short', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true }),
        status: result.success ? 'Sent' : 'Failed',
        errorMessage: result.success ? undefined : result.message
      };

      if (!db.emailLogs) db.emailLogs = [];
      db.emailLogs.unshift(newLog);
      await writeDatabase(db);

      res.json({
        success: result.success,
        message: result.message,
        logs: result.logs,
        logEntry: newLog
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/email/send', async (req, res) => {
    try {
      const { patientId, templateId, subject, body } = req.body;
      const db = await readDatabase();
      const patient = db.patients.find(item => item.id === patientId);
      if (!patient) return res.status(404).json({ error: 'Patient not found.' });
      if (!patient.email) return res.status(400).json({ error: 'This patient does not have an email address.' });

      const template = db.emailTemplates?.find(item => item.id === templateId);
      if (!template) return res.status(404).json({ error: 'Email template not found.' });

      const finalSubject = String(subject || template.subject).trim();
      const finalBody = String(body || template.body).trim();
      if (!finalSubject || !finalBody) return res.status(400).json({ error: 'Subject and message are required.' });

      const config = db.smtpConfig || {
        host: BREVO_SMTP_HOST, port: BREVO_SMTP_PORT, user: BREVO_SMTP_USER || '', pass: BREVO_SMTP_PASSWORD || '', secure: false,
        fromEmail: BREVO_FROM_EMAIL || '', senderName: BREVO_SENDER_NAME, replyTo: BREVO_REPLY_TO
      };
      if (!BREVO_API_KEY && !BREVO_SMTP_PASSWORD && !db.smtpConfig) return res.status(400).json({ error: 'Configure Brevo API or SMTP before sending email.' });

      const result = await sendEmail(config, patient.email, finalSubject, finalBody);
      const newLog: EmailLog = {
        id: `log_${Date.now()}`,
        recipientEmail: patient.email,
        patientName: patient.name,
        subject: finalSubject,
        body: finalBody,
        templateName: template.name,
        sentAt: new Date().toLocaleString('en-US', {
          month: 'short',
          day: '2-digit',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          hour12: true
        }),
        status: result.success ? 'Sent' : 'Failed',
        errorMessage: result.success ? undefined : result.message
      };

      if (!db.emailLogs) db.emailLogs = [];
      db.emailLogs.unshift(newLog);
      await writeDatabase(db);

      res.status(result.success ? 200 : 502).json({
        success: result.success,
        message: result.message,
        logEntry: newLog
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/sms/config', async (_req, res) => {
    res.json({ configured: Boolean(RC_APP_CLIENT_ID && RC_APP_CLIENT_SECRET && RC_USER_JWT && RC_FROM_PHONE_NUMBER), provider: 'RingCentral' });
  });

  // Verify the RingCentral JWT without sending a message. This keeps setup
  // checks safe and gives the UI a useful diagnostic before a clinic sends.
  app.post('/api/sms/verify', async (_req, res) => {
    try {
      await getRingCentralAccessToken();
      res.json({ success: true, message: 'RingCentral is connected and ready to send SMS.' });
    } catch (err: any) {
      res.status(502).json({ success: false, error: err.message });
    }
  });

  app.get('/api/sms/templates', async (_req, res) => {
    const db = await readDatabase();
    const templates: SmsTemplate[] = db.smsTemplates?.length ? db.smsTemplates : [
      { id: 'sms_appointment', name: 'Appointment reminder', body: 'Hi {patientName}, this is a reminder from {clinicName} about your {appointmentType}. Please call us if you need help.', triggerEvent: 'appointment_booked' },
      { id: 'sms_documents', name: 'Documents needed', body: 'Hi {patientName}, {clinicName} still needs a document from you before we can continue your care. Please contact us when ready.', triggerEvent: 'documents_needed' },
      { id: 'sms_auth', name: 'Insurance update', body: 'Hi {patientName}, we have an update about your insurance approval. Please contact {clinicName} so we can help with the next step.', triggerEvent: 'auth_status_approved' },
      { id: 'sms_fitting', name: 'Fitting reminder', body: 'Hi {patientName}, your fitting with {clinicName} is coming up. Please call us if you need to reschedule.', triggerEvent: 'fitting_reminder' }
    ];
    res.json({ smsTemplates: templates });
  });

  app.post('/api/sms/send', async (req, res) => {
    try {
      const { patientId, templateId, body } = req.body;
      const db = await readDatabase();
      const patient = db.patients.find(item => item.id === patientId);
      if (!patient) return res.status(404).json({ error: 'Patient not found.' });
      if (!patient.phone) return res.status(400).json({ error: 'This patient does not have a phone number.' });
      const templates: SmsTemplate[] = db.smsTemplates?.length ? db.smsTemplates : [
        { id: 'sms_appointment', name: 'Appointment reminder', body: 'Hi {patientName}, this is a reminder from {clinicName} about your {appointmentType}. Please call us if you need help.', triggerEvent: 'appointment_booked' },
        { id: 'sms_documents', name: 'Documents needed', body: 'Hi {patientName}, {clinicName} still needs a document from you before we can continue your care. Please contact us when ready.', triggerEvent: 'documents_needed' },
        { id: 'sms_auth', name: 'Insurance update', body: 'Hi {patientName}, we have an update about your insurance approval. Please contact {clinicName} so we can help with the next step.', triggerEvent: 'auth_status_approved' },
        { id: 'sms_fitting', name: 'Fitting reminder', body: 'Hi {patientName}, your fitting with {clinicName} is coming up. Please call us if you need to reschedule.', triggerEvent: 'fitting_reminder' }
      ];
      const template = templates.find(item => item.id === templateId) || templates[0];
      const finalBody = String(body || template?.body || '').trim();
      if (!finalBody) return res.status(400).json({ error: 'Message is required.' });
      const result = await sendRingCentralSms(patient.phone, finalBody);
      const log: SmsLog = { id: `smslog_${Date.now()}`, patientId: patient.id, patientName: patient.name, recipientPhone: patient.phone, message: finalBody, templateName: template?.name || 'Custom message', sentAt: new Date().toLocaleString(), status: 'Sent', providerMessageId: result.messageId };
      db.smsLogs = [log, ...(db.smsLogs || [])];
      await writeDatabase(db);
      res.json({ success: true, message: 'SMS sent through RingCentral.', logEntry: log });
    } catch (err: any) {
      res.status(502).json({ error: err.message });
    }
  });

  // 1. Get complete DB state
  app.get('/api/data', async (req, res) => {
    try {
      const db = await readDatabase();
      res.json(db);
    } catch (err: any) {
      res.status(503).json({
        error: `Hostinger MySQL is unavailable: ${mysqlErrorMessage(err)}`,
        hint: mysqlErrorHint(err),
        persistence: 'mysql',
        code: err?.code || 'DATABASE_UNAVAILABLE'
      });
    }
  });

  // 2. Add Patient
  app.post('/api/patients', async (req, res) => {
    try {
      const {
        name, phone, dob, email, referralSource, status, files, insuranceCompany,
        insuranceId, primaryClinician, address, gender, diagnosis, deviceCategory,
        affectedSide, careStage, allergies, communicationPreference, consentStatus,
        notes
      } = req.body;
      if (!name) {
        return res.status(400).json({ error: 'Name is required' });
      }

      const db = await readDatabase();
      const normalizedName = normalizePatientField(name);
      const normalizedPhone = normalizePatientField(phone);
      const normalizedEmail = normalizePatientField(email);
      const existingPatient = db.patients.find(patient => (
        (normalizedName.length >= 2 && normalizePatientField(patient.name) === normalizedName)
        || (normalizedPhone.length >= 7 && normalizePatientField(patient.phone) === normalizedPhone)
        || (normalizedEmail.length >= 5 && normalizePatientField(patient.email) === normalizedEmail)
      ));
      if (existingPatient) {
        return res.status(409).json({
          error: 'This patient already exists. Use the existing patient record to book an appointment.',
          existingPatient
        });
      }

      const generatedMrn = generateMRN();
      const newPatient: Patient = {
        id: `p_${Date.now()}`,
        name: String(name).trim(),
        phone: phone || '',
        dob: dob || '',
        email: email || '',
        referralSource: referralSource || 'other',
        status: status || 'In Progress',
        mrn: generatedMrn,
        avatarInitials: getInitials(name),
        files: Array.isArray(files) ? files : [],
        insuranceCompany: insuranceCompany || '',
        insuranceId: insuranceId || '',
        primaryClinician: primaryClinician || '',
        address: address || '',
        gender: gender || 'Not specified',
        clinicalNotes: notes ? [{ id: `note_${Date.now()}`, date: new Date().toISOString(), author: primaryClinician || 'Admin', text: String(notes), subjective: String(notes) }] : [],
        diagnosis: diagnosis || '',
        deviceCategory: deviceCategory || undefined,
        affectedSide: affectedSide || undefined,
        careStage: careStage || 'Referral',
        allergies: Array.isArray(allergies) ? allergies : [],
        communicationPreference: communicationPreference || undefined,
        consentStatus: consentStatus || undefined
      };
      db.patients.unshift(newPatient);

      if (status === 'Consultation') {
        db.appointments.unshift({
          id: `a_${Date.now()}`,
          patientId: newPatient.id,
          patientName: name,
          time: '02:00 PM',
          type: 'Initial Consult',
          status: 'Scheduled',
          initials: getInitials(name)
        });
      }

      await writeDatabase(db);
      res.status(201).json(newPatient);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 3. Update Patient Status / Column Position
  app.patch('/api/patients/:id/status', async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;

      const db = await readDatabase();
      const updatedPatient = db.patients.find(p => p.id === id);
      if (!updatedPatient) {
        return res.status(404).json({ error: 'Patient not found' });
      }
      updatedPatient.status = status;

      if (status === 'Consultation') {
        db.appointments.unshift({
          id: `a_${Date.now()}`,
          patientId: updatedPatient.id,
          patientName: updatedPatient.name,
          time: '02:00 PM',
          type: 'Initial Consult',
          status: 'Scheduled',
          initials: getInitials(updatedPatient.name)
        });
      }

      await writeDatabase(db);
      res.json(updatedPatient);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 3a. Comprehensive Patient Update (Demographics, Insurance, Notes)
  app.patch('/api/patients/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const { name, phone, dob, email, referralSource, status, careStage, insuranceCompany, insuranceId, address, gender, clinicalNotes, avatarUrl, important } = req.body;

      const db = await readDatabase();
      const patient = db.patients.find(p => p.id === id);
      if (!patient) {
        return res.status(404).json({ error: 'Patient not found' });
      }

      if (name !== undefined && name.trim() && name.trim() !== patient.name) {
        const previousName = patient.name.trim().toLowerCase();
        const matchesPreviousName = (value?: string) => value?.trim().toLowerCase() === previousName;
        db.appointments.forEach(item => {
          if (item.patientId === id || matchesPreviousName(item.patientName)) {
            item.patientId = id;
            item.patientName = name.trim();
            item.initials = getInitials(name.trim());
          }
        });
        db.authorizations.forEach(item => {
          if (item.patientId === id || matchesPreviousName(item.patientName)) {
            item.patientId = id;
            item.patientName = name.trim();
          }
        });
        db.claims.forEach(item => {
          if (item.patientId === id || matchesPreviousName(item.patientName)) {
            item.patientId = id;
            item.patientName = name.trim();
          }
        });
        db.fabrication.forEach(item => {
          if (item.patientId === id || matchesPreviousName(item.patientName)) {
            item.patientId = id;
            item.patientName = name.trim();
          }
        });
        patient.name = name.trim();
      }
      if (phone !== undefined) patient.phone = phone;
      if (dob !== undefined) patient.dob = dob;
      if (email !== undefined) patient.email = email;
      if (referralSource !== undefined) patient.referralSource = referralSource;
      if (status !== undefined) patient.status = status;
      if (careStage !== undefined) patient.careStage = careStage;
      if (insuranceCompany !== undefined) patient.insuranceCompany = insuranceCompany;
      if (insuranceId !== undefined) patient.insuranceId = insuranceId;
      if (address !== undefined) patient.address = address;
      if (gender !== undefined) patient.gender = gender;
      if (clinicalNotes !== undefined) patient.clinicalNotes = clinicalNotes;
      if (avatarUrl !== undefined) patient.avatarUrl = avatarUrl;
      if (important !== undefined) patient.important = Boolean(important);
      patient.avatarInitials = getInitials(patient.name);

      await writeDatabase(db);
      res.json(patient);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 3b. Add Appointment
  app.post('/api/appointments', async (req, res) => {
    try {
      const { patientName, time, type, status, appt_date } = req.body;
      if (!patientName) {
        return res.status(400).json({ error: 'Patient name is required' });
      }

      const db = await readDatabase();
      const matchedPatient = db.patients.find(p => p.name.trim().toLowerCase() === patientName.trim().toLowerCase());
      if (!matchedPatient) return res.status(400).json({ error: 'Select an existing patient.' });
      const newAppointment: Appointment = {
        id: `a_${Date.now()}`,
        patientId: matchedPatient.id,
        patientName: matchedPatient.name,
        time: time || '09:00 AM',
        type: type || 'Consultation',
        status: status || 'Scheduled',
        initials: getInitials(patientName),
        date: appt_date || new Date().toISOString().split('T')[0]
      };
      db.appointments.unshift(newAppointment);
      await writeDatabase(db);

      const notifications: { email?: { success: boolean; message: string }; sms?: { success: boolean; message: string } } = {};
      const appointmentDate = newAppointment.date || new Date().toISOString().split('T')[0];

      if (matchedPatient.email) {
        const emailMessage = appointmentEmail(matchedPatient, appointmentDate, newAppointment.time);
        const config = db.smtpConfig || { host: BREVO_SMTP_HOST, port: BREVO_SMTP_PORT, user: BREVO_SMTP_USER || '', pass: BREVO_SMTP_PASSWORD || '', secure: false, fromEmail: BREVO_FROM_EMAIL || appointmentClinic.email, senderName: appointmentClinic.name, replyTo: BREVO_REPLY_TO };
        const result = await sendEmail(config, matchedPatient.email, emailMessage.subject, emailMessage.text, [], emailMessage.html);
        notifications.email = { success: result.success, message: result.message };
        const log: EmailLog = {
          id: `log_${Date.now()}`,
          recipientEmail: matchedPatient.email,
          patientName: matchedPatient.name,
          subject: emailMessage.subject,
          body: emailMessage.text,
          templateName: 'Automatic appointment confirmation',
          sentAt: new Date().toLocaleString('en-US', { month: 'short', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true }),
          status: result.success ? 'Sent' : 'Failed',
          errorMessage: result.success ? undefined : result.message
        };
        db.emailLogs = [log, ...(db.emailLogs || [])];
      }

      if (matchedPatient.phone) {
        try {
          const result = await sendRingCentralSms(matchedPatient.phone, appointmentSms(matchedPatient, appointmentDate, newAppointment.time));
          notifications.sms = { success: true, message: `SMS sent through RingCentral${result.messageId ? ` (${result.messageId})` : ''}.` };
        } catch (notificationError: any) {
          notifications.sms = { success: false, message: notificationError.message || 'SMS could not be sent.' };
        }
      }

      if (matchedPatient.email) await writeDatabase(db);
      res.status(201).json({ ...newAppointment, notifications });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 3c. Update Appointment Status / Details
  app.patch('/api/appointments/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const { status, time, type, patientName, appt_date } = req.body;

      const db = await readDatabase();
      const appt = db.appointments.find(a => a.id === id);
      if (!appt) {
        return res.status(404).json({ error: 'Appointment not found' });
      }
      if (status !== undefined) appt.status = status;
      if (time !== undefined) appt.time = time;
      if (type !== undefined) appt.type = type;
      if (patientName !== undefined) {
        appt.patientName = patientName;
        appt.initials = getInitials(patientName);
      }
      if (appt_date !== undefined) appt.date = appt_date;
      await writeDatabase(db);
      res.json(appt);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 3d. Delete Patient completely (Admin)
  app.delete('/api/patients/:id', async (req, res) => {
    try {
      const { id } = req.params;

      const db = await readDatabase();
      const patient = db.patients.find(p => p.id === id);
      if (!patient) {
        return res.status(404).json({ error: 'Patient not found' });
      }

      const patientName = patient.name.trim().toLowerCase();
      const belongsToPatient = (name?: string) => name?.trim().toLowerCase() === patientName;

      db.patients = db.patients.filter(p => p.id !== id);
      db.appointments = db.appointments.filter(item => item.patientId !== id && !belongsToPatient(item.patientName));
      db.authorizations = db.authorizations.filter(item => item.patientId !== id && !belongsToPatient(item.patientName));
      db.claims = db.claims.filter(item => item.patientId !== id && !belongsToPatient(item.patientName));
      db.fabrication = db.fabrication.filter(item => item.patientId !== id && !belongsToPatient(item.patientName));
      db.emailLogs = (db.emailLogs || []).filter(item => !belongsToPatient(item.patientName));
      db.alerts = db.alerts.filter(item => !item.message.toLowerCase().includes(patientName));
      await writeDatabase(db);

      res.json({ success: true, message: 'Patient and all linked workflow records deleted successfully' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 3e. Delete Appointment completely (Admin)
  app.delete('/api/appointments/:id', async (req, res) => {
    try {
      const { id } = req.params;

      const db = await readDatabase();
      db.appointments = db.appointments.filter(a => a.id !== id);
      await writeDatabase(db);

      res.json({ success: true, message: 'Appointment deleted successfully' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 4. "Upload" file to patient
  app.post('/api/patients/:id/files', async (req, res) => {
    try {
      const { id } = req.params;
      const { name, type, size, content, description } = req.body;

      if (!name) {
        return res.status(400).json({ error: 'Filename is required' });
      }

      const db = await readDatabase();
      const patient = db.patients.find(p => p.id === id);
      if (!patient) {
        return res.status(404).json({ error: 'Patient not found' });
      }

      const newFile = {
        id: `f_${Date.now()}`,
        name,
        type: type || 'pdf',
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
        size: size || '1.0 MB',
        content: content || '' // Direct base64 content
        , description: description || ''
      };

      patient.files = [newFile, ...(patient.files || [])] as PatientFile[];
      await writeDatabase(db);

      res.status(201).json(newFile);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 5. Delete file from patient
  app.delete('/api/patients/:id/files/:fileId', async (req, res) => {
    try {
      const { id, fileId } = req.params;

      const db = await readDatabase();
      const patient = db.patients.find(p => p.id === id);
      if (!patient) {
        return res.status(404).json({ error: 'Patient not found' });
      }

      patient.files = (patient.files || []).filter((f: any) => f.id !== fileId);
      await writeDatabase(db);

      res.json({ success: true, message: 'File deleted' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 6. Update/Create Authorization
  app.patch('/api/authorizations/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const { status, payer, authNumber, notes } = req.body;

      const db = await readDatabase();
      const auth = db.authorizations.find(a => a.id === id);

      if (!auth) {
        return res.status(404).json({ error: 'Authorization not found' });
      }

      if (status !== undefined) auth.status = status;
      if (payer !== undefined) auth.payer = payer;
      if (authNumber !== undefined) auth.authNumber = authNumber;
      if (notes !== undefined) auth.notes = notes;

      await writeDatabase(db);

      res.json(auth);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 7. Add Authorization
  app.post('/api/authorizations', async (req, res) => {
    try {
      const { patientName, device, payer, status, notes } = req.body;
      if (!patientName || !device) {
        return res.status(400).json({ error: 'patientName and device are required' });
      }

      const db = await readDatabase();
      const matchedPatient = db.patients.find(p => p.name.trim().toLowerCase() === patientName.trim().toLowerCase());
      if (!matchedPatient) return res.status(400).json({ error: 'Select an existing patient.' });
      const newAuth: Authorization = {
        id: `au_${Date.now()}`,
        patientId: matchedPatient.id,
        patientName: matchedPatient.name,
        device,
        status: status || 'Pending',
        submittedDate: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
        daysWaiting: 1,
        payer: payer || 'Private Pay',
        notes: notes || ''
      };

      db.authorizations.unshift(newAuth);
      await writeDatabase(db);
      res.status(201).json(newAuth);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 8. Add Claim
  app.post('/api/claims', async (req, res) => {
    try {
      const { patientName, patientId, payer, doctor, amount, status, sendInvoice = false, invoicePurpose, serviceDescription, repairDetails, paymentMethod, serviceTotal, gratuity, warrantyDays } = req.body;
      if (!patientName || !amount) {
        return res.status(400).json({ error: 'patientName and amount are required' });
      }

      const db = await readDatabase();
      const matchedPatient = patientId
        ? db.patients.find(p => p.id === patientId)
        : db.patients.find(p => p.name.trim().toLowerCase() === patientName.trim().toLowerCase());
      if (!matchedPatient) return res.status(400).json({ error: 'Select an existing patient.' });
      const count = db.claims.length + 890;
      const newClaim: Claim = {
        id: `c_${Date.now()}`,
        patientId: matchedPatient.id,
        claimNumber: `INV-2023-0${count}`,
        patientName: matchedPatient.name,
        payer: payer || 'Self',
        doctor: doctor || 'Dr. Deepak Kumar Bhardwaj',
        amount: parseFloat(amount),
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit' }),
        status: status || 'Billed',
        serviceDescription: serviceDescription || invoicePurpose || 'Orthotic and prosthetic clinical services',
        repairDetails: repairDetails || '',
        paymentMethod: paymentMethod || 'Self-pay',
        serviceTotal: Number(serviceTotal || amount),
        gratuity: Number(gratuity || 0),
        warrantyDays: Number(warrantyDays || 30),
        invoicePurpose: invoicePurpose || 'Payment for services'
      };

      db.claims.unshift(newClaim);
      await writeDatabase(db);

      let emailResult: { success: boolean; message: string } | undefined;
      if (sendInvoice) {
        if (!matchedPatient.email) {
          emailResult = { success: false, message: 'Invoice saved, but this patient does not have an email address.' };
        } else {
          const invoicePdf = buildInvoicePdf({ patient: matchedPatient, claimNumber: newClaim.claimNumber, payer: newClaim.payer, doctor: newClaim.doctor, amount: newClaim.amount, date: newClaim.date, clinic: db.settings, serviceDescription: newClaim.serviceDescription, repairDetails: newClaim.repairDetails, paymentMethod: newClaim.paymentMethod, serviceTotal: newClaim.serviceTotal, gratuity: newClaim.gratuity, warrantyDays: newClaim.warrantyDays });
          const finalSubject = `Paid invoice ${newClaim.claimNumber} - ${db.settings.clinicName}`;
          const finalBody = `Hello ${matchedPatient.name},\n\nPlease find your invoice and receipt attached for ${moneyForEmail(newClaim.amount)}.\n\nInvoice: ${newClaim.claimNumber}\nBilling payer: ${newClaim.payer}\nClinician: ${newClaim.doctor}\n\nIf you have questions, please contact ${db.settings.supportEmail || 'our billing team'}.\n\nSincerely,\n${db.settings.clinicName}`;
          const config = db.smtpConfig || { host: BREVO_SMTP_HOST, port: BREVO_SMTP_PORT, user: BREVO_SMTP_USER || '', pass: BREVO_SMTP_PASSWORD || '', secure: false, fromEmail: BREVO_FROM_EMAIL || '', senderName: BREVO_SENDER_NAME, replyTo: BREVO_REPLY_TO };
          const result = await sendEmail(config, matchedPatient.email, finalSubject, finalBody, [{ name: `${newClaim.claimNumber}.pdf`, content: invoicePdf.toString('base64'), contentType: 'application/pdf' }]);
          emailResult = { success: result.success, message: result.message };
          const emailLog: EmailLog = {
            id: `log_${Date.now()}`,
            recipientEmail: matchedPatient.email,
            patientName: matchedPatient.name,
            subject: finalSubject,
            body: finalBody,
            templateName: 'Paid invoice receipt',
            sentAt: new Date().toLocaleString('en-US', { month: 'short', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true }),
            status: result.success ? 'Sent' : 'Failed',
            errorMessage: result.success ? undefined : result.message
          };
          db.emailLogs = [emailLog, ...(db.emailLogs || [])];
          await writeDatabase(db);
        }
      }

      res.status(201).json({ ...newClaim, emailResult });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/claims/:id/invoice.pdf', async (req, res) => {
    try {
      const db = await readDatabase();
      const claim = db.claims.find(item => item.id === req.params.id);
      if (!claim) return res.status(404).json({ error: 'Invoice not found.' });
      const patient = db.patients.find(item => item.id === claim.patientId) || db.patients.find(item => item.name === claim.patientName);
      if (!patient) return res.status(404).json({ error: 'Patient not found.' });
      const pdf = buildInvoicePdf({ patient, claimNumber: claim.claimNumber, payer: claim.payer, doctor: claim.doctor, amount: claim.amount, date: claim.date, clinic: db.settings, serviceDescription: claim.serviceDescription, repairDetails: claim.repairDetails, paymentMethod: claim.paymentMethod, serviceTotal: claim.serviceTotal, gratuity: claim.gratuity, warrantyDays: claim.warrantyDays });
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${claim.claimNumber}.pdf"`);
      res.send(pdf);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/claims/:id/send', async (req, res) => {
    try {
      const db = await readDatabase();
      const claim = db.claims.find(item => item.id === req.params.id);
      if (!claim) return res.status(404).json({ error: 'Invoice not found.' });
      const patient = db.patients.find(item => item.id === claim.patientId) || db.patients.find(item => item.name === claim.patientName);
      if (!patient) return res.status(404).json({ error: 'Patient not found.' });
      if (!patient.email) return res.status(400).json({ error: 'This patient does not have an email address.' });
      const invoicePdf = buildInvoicePdf({ patient, claimNumber: claim.claimNumber, payer: claim.payer, doctor: claim.doctor, amount: claim.amount, date: claim.date, clinic: db.settings, serviceDescription: claim.serviceDescription, repairDetails: claim.repairDetails, paymentMethod: claim.paymentMethod, serviceTotal: claim.serviceTotal, gratuity: claim.gratuity, warrantyDays: claim.warrantyDays });
      const subject = `Invoice ${claim.claimNumber} - ${db.settings.clinicName}`;
      const body = `Hello ${patient.name},\n\nPlease find your invoice attached.\n\nInvoice: ${claim.claimNumber}\nAmount: ${moneyForEmail(claim.amount)}\nBilling payer: ${claim.payer}\nClinician: ${claim.doctor}\n\nIf you have questions, please contact ${db.settings.supportEmail || 'our billing team'}.\n\nSincerely,\n${db.settings.clinicName}`;
      const config = db.smtpConfig || { host: BREVO_SMTP_HOST, port: BREVO_SMTP_PORT, user: BREVO_SMTP_USER || '', pass: BREVO_SMTP_PASSWORD || '', secure: false, fromEmail: BREVO_FROM_EMAIL || '', senderName: BREVO_SENDER_NAME, replyTo: BREVO_REPLY_TO };
      const result = await sendEmail(config, patient.email, subject, body, [{ name: `${claim.claimNumber}.pdf`, content: invoicePdf.toString('base64'), contentType: 'application/pdf' }]);
      const log: EmailLog = { id: `log_${Date.now()}`, recipientEmail: patient.email, patientName: patient.name, subject, body, templateName: 'Invoice receipt resend', sentAt: new Date().toLocaleString('en-US', { month: 'short', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true }), status: result.success ? 'Sent' : 'Failed', errorMessage: result.success ? undefined : result.message };
      db.emailLogs = [log, ...(db.emailLogs || [])];
      await writeDatabase(db);
      res.status(result.success ? 200 : 502).json({ success: result.success, message: result.message, logEntry: log });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 8a. Update Claim Status
  app.patch('/api/claims/:id/status', async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      const db = await readDatabase();
      const claim = db.claims.find(c => c.id === id);
      if (!claim) {
        return res.status(404).json({ error: 'Claim not found' });
      }
      claim.status = status;
      await writeDatabase(db);
      res.json(claim);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 8b. Delete Claim Invoice
  app.delete('/api/claims/:id', async (req, res) => {
    try {
      const db = await readDatabase();
      const claimIndex = db.claims.findIndex(claim => claim.id === req.params.id);
      if (claimIndex === -1) {
        return res.status(404).json({ error: 'Invoice not found' });
      }

      const [deletedClaim] = db.claims.splice(claimIndex, 1);
      await writeDatabase(db);
      res.json({ success: true, claim: deletedClaim });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 9. Update Clinic Settings
  app.put('/api/settings', async (req, res) => {
    try {
      const { clinicName, primaryAddress, contactPhone, supportEmail, requirePin, pinCode, appearance, logoUrl, doctorName, doctorImageUrl, defaultReferralSource, defaultPrimaryClinician } = req.body;

      const db = await readDatabase();
      db.settings = {
        clinicName: clinicName || db.settings.clinicName,
        primaryAddress: primaryAddress || db.settings.primaryAddress,
        contactPhone: contactPhone || db.settings.contactPhone,
        supportEmail: supportEmail || db.settings.supportEmail,
        requirePin: requirePin !== undefined ? requirePin : db.settings.requirePin,
        pinCode: pinCode || db.settings.pinCode,
        appearance: appearance || db.settings.appearance,
        logoUrl: logoUrl !== undefined ? logoUrl : db.settings.logoUrl,
        doctorName: doctorName !== undefined ? doctorName : db.settings.doctorName,
        doctorImageUrl: doctorImageUrl !== undefined ? doctorImageUrl : db.settings.doctorImageUrl,
        defaultReferralSource: defaultReferralSource !== undefined ? defaultReferralSource : db.settings.defaultReferralSource,
        defaultPrimaryClinician: defaultPrimaryClinician !== undefined ? defaultPrimaryClinician : db.settings.defaultPrimaryClinician
      };

      await writeDatabase(db);
      res.json(db.settings);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 10. Update Fabrication Item
  app.post('/api/fabrication', async (req, res) => {
    try {
      const { patientName, device, stage, priority, specifications } = req.body;
      if (!patientName || !device) {
        return res.status(400).json({ error: 'patientName and device are required' });
      }

      const db = await readDatabase();
      const matchedPatient = db.patients.find(p => p.name.trim().toLowerCase() === patientName.trim().toLowerCase());
      if (!matchedPatient) return res.status(400).json({ error: 'Select an existing patient.' });

      const item: FabricationItem = {
        id: `fab_${Date.now()}`,
        patientId: matchedPatient.id,
        patientName: matchedPatient.name,
        device,
        stage: stage || 'Layout',
        priority: priority === 'High' || priority === 'Urgent' ? 'Urgent' : 'Standard',
        techNotes: specifications || 'Created from guided visit flow.',
        updatedAt: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit' })
      };

      db.fabrication.unshift(item);
      await writeDatabase(db);
      res.status(201).json(item);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.patch('/api/fabrication/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const { stage, techNotes, priority } = req.body;

      const db = await readDatabase();
      const item = db.fabrication.find(f => f.id === id);

      if (!item) {
        return res.status(404).json({ error: 'Fabrication item not found' });
      }

      if (stage !== undefined) item.stage = stage;
      if (techNotes !== undefined) item.techNotes = techNotes;
      if (priority !== undefined) item.priority = priority;
      item.updatedAt = new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit' });

      await writeDatabase(db);

      res.json(item);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 11. Dismiss Alert Notification
  app.delete('/api/alerts/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const db = await readDatabase();
      db.alerts = db.alerts.filter(a => a.id !== id);
      await writeDatabase(db);
      res.json({ success: true, message: 'Alert notification dismissed' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 12. Send Simulated Email & Append Live Alert
  app.post('/api/send-email', async (req, res) => {
    try {
      const { email, patientName, subject, message } = req.body;
      if (!email || !patientName) {
        return res.status(400).json({ error: 'Recipient email and patient name are required' });
      }

      const db = await readDatabase();
      const newAlert: AlertItem = {
        id: `al_${Date.now()}`,
        type: 'info',
        title: 'Reminder Dispatched',
        message: `Appointment reminder successfully sent to ${patientName} (${email}).`,
        actionText: 'Review List',
        actionTarget: 'tracker'
      };
      db.alerts.unshift(newAlert);
      await writeDatabase(db);

      console.log(`[SIMULATED EMAIL TRANS] To: ${email} | Subject: ${subject} | Msg: ${message}`);

      res.status(200).json({ success: true, message: 'Email reminder sent successfully', alert: newAlert });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Vite Integration
  // Hostinger Passenger may not provide NODE_ENV. Only opt into Vite when
  // development is explicitly requested; deployed Node apps must serve the
  // already-built dist/ bundle.
  if (process.env.NODE_ENV === 'development') {
    const hmrPort = await findAvailablePort(Number(process.env.VITE_HMR_PORT || 24678));
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: {
          port: hmrPort
        }
      },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const httpServer = app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
  httpServer.on('error', (error: NodeJS.ErrnoException) => {
    if (error.code === 'EADDRINUSE') {
      console.error(`Port ${PORT} is already in use. The existing Genfinity server may already be running.`);
      httpServer.close();
      setImmediate(() => process.exit(0));
      return;
    }
    console.error('Unable to start Genfinity server:', error);
    process.exitCode = 1;
  });
}

startServer();
